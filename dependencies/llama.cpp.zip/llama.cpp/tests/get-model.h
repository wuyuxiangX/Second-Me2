#pragma once
char * get_model_or_exit(int, char*[]);
