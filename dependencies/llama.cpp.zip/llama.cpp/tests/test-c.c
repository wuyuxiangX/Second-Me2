#include "llama.h"

#ifdef GGML_USE_KOMPUTE
#include "ggml-kompute.h"
#endif

int main(void) {}
